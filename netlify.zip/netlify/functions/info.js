// Coded by Awnish - Instagram Profile Info API for Netlify
exports.handler = async (event, context) => {
  const { queryStringParameters } = event;
  const username = queryStringParameters?.username;

  // Check if username is provided
  if (!username) {
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "missing_username", usage: "/.netlify/functions/info?username=<name>" }, null, 2)
    };
  }

  try {
    // Fetch data from Instagram's unofficial API
    const response = await fetch(`https://i.instagram.com/api/v1/users/web_profile_info/?username=${username}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "x-ig-app-id": "936619743392459",
        "Accept": "application/json",
        "Referer": `https://www.instagram.com/${username}/`
      }
    });

    // Handle specific errors
    if (response.status === 404) {
      return {
        statusCode: 404,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "user_not_found" }, null, 2)
      };
    }
    if (!response.ok) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "instagram_api_error", status: response.status }, null, 2)
      };
    }

    const data = await response.json();
    const userData = data?.data?.user;

    // If no user data, return raw response for debugging
    if (!userData) {
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "invalid_response", raw: data }, null, 2)
      };
    }

    // Extract recent posts (up to 8)
    const mediaEdges = userData.edge_owner_to_timeline_media?.edges || [];
    const recentPosts = mediaEdges.slice(0, 8).map(edge => {
      const node = edge.node || edge;
      return {
        id: node.id,
        code: node.shortcode,
        image: node.display_url,
        caption: node.edge_media_to_caption?.edges?.[0]?.node?.text || null
      };
    });

    // Build and return user profile data
    const profile = {
      id: userData.id,
      username: userData.username,
      full_name: userData.full_name,
      bio: userData.biography,
      is_verified: userData.is_verified,
      is_private: userData.is_private,
      profile_pic: userData.profile_pic_url_hd || userData.profile_pic_url,
      followers: userData.edge_followed_by?.count || 0,
      following: userData.edge_follow?.count || 0,
      posts_count: userData.edge_owner_to_timeline_media?.count || 0,
      recent_posts: recentPosts
    };

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(profile, null, 2)
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "server_error", message: error.message }, null, 2)
    };
  }
};